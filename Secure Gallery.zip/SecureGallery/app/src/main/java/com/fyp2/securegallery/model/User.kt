package com.fyp2.securegallery.model

data class User(
    val pin: String,
    val email: String,
    
)